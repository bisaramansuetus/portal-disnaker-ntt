<?php
namespace Database\Seeders;
use App\Models\User;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

class UserSeeder extends Seeder {
    public function run(): void {
        User::updateOrCreate(
            ['email' => 'admin@disnakerntt.test'],
            [
                'name' => 'Administrator',
                'password' => Hash::make('password123'), // ganti setelah login!
                'role' => 'admin',
            ]
        );
    }
}