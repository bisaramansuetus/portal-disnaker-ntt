
<?php $__env->startSection('title', 'Informasi Publik (PPID)'); ?>

<?php $__env->startSection('content'); ?>
    <div class="max-w-5xl mx-auto px-4 py-12">
        <div class="bg-white rounded-xl shadow-sm border-t-4 border-ntt-gold p-8 md:p-12">
            <h1 class="text-3xl font-bold text-ntt-red font-serif mb-2">Daftar Informasi Publik</h1>
            <p class="text-gray-600 mb-8 border-b pb-4">Sesuai dengan UU No. 14 Tahun 2008 tentang Keterbukaan Informasi Publik.</p>

            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if(isset($documents[$cat])): ?>
                    <div class="mb-8">
                        <h2 class="text-xl font-bold text-slate-800 mb-4 bg-gray-100 p-3 rounded"><?php echo e($cat); ?></h2>
                        <div class="overflow-x-auto">
                            <table class="w-full text-sm text-left border">
                                <thead class="bg-slate-800 text-white">
                                    <tr>
                                        <th class="px-4 py-3">Nama Dokumen</th>
                                        <th class="px-4 py-3 w-32 text-center">Aksi</th>
                                    </tr>
                                </thead>
                                <tbody class="divide-y">
                                    <?php $__currentLoopData = $documents[$cat]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr class="hover:bg-gray-50">
                                            <td class="px-4 py-3 font-medium"><?php echo e($doc->title); ?></td>
                                            <td class="px-4 py-3 text-center space-x-2 whitespace-nowrap">
                                                
                                                
                                                <a href="<?php echo e(asset('storage/' . $doc->file_path)); ?>" target="_blank" rel="noopener" 
                                                   class="inline-block border border-blue-600 text-blue-600 px-3 py-1 rounded text-xs hover:bg-blue-50 transition font-semibold">
                                                    👁️ Baca
                                                </a>

                                                
                                                <a href="<?php echo e(route('site.ppid.download', $doc)); ?>" 
                                                   class="inline-block bg-blue-600 text-white px-3 py-1 rounded text-xs hover:bg-blue-700 transition font-semibold">
                                                    ⬇ Unduh
                                                </a>

                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.site', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\disnaker-ntt\resources\views/site/ppid/documents.blade.php ENDPATH**/ ?>