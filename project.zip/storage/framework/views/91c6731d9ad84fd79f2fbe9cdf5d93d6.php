<?php $__env->startSection('content'); ?>
<?php
    $isTransmigration = request('type') === 'transmigrasi' || ($mode ?? '') === 'transmigration';
    $pageTitle = $isTransmigration ? 'Harapan baru, bersama transmigrasi.' : 'Belajar, tumbuh, berdaya.';
    $pageSubtitle = $isTransmigration
        ? 'Kenali program, persyaratan, dan proses pendampingan transmigrasi.'
        : 'Pilih pelatihan sesuai minat dan kembangkan keterampilan yang relevan.';
    $breadcrumbLabel = $isTransmigration ? 'Harapan baru, bersama transmigrasi' : 'Belajar, tumbuh, berdaya';
?>

<div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 md:py-14">
    <!-- Breadcrumb -->
    <nav class="text-xs text-gray-500 mb-4">
        <a href="<?php echo e(route('home')); ?>" class="hover:underline">Beranda</a> / <span>Informasi</span> / <span class="text-gray-900 font-medium"><?php echo e($breadcrumbLabel); ?></span>
    </nav>

    <!-- Header -->
    <div class="max-w-2xl mb-8">
        <h1 class="text-3xl sm:text-4xl font-extrabold text-gray-900 tracking-tight mb-2"><?php echo e($pageTitle); ?></h1>
        <p class="text-sm sm:text-base text-gray-600"><?php echo e($pageSubtitle); ?></p>
    </div>

    <!-- Search & Filter Bar -->
    <form method="GET" action="<?php echo e(route('site.programs.index')); ?>" class="bg-white rounded-2xl p-2.5 border border-gray-200/80 shadow-xs flex flex-col md:flex-row items-stretch md:items-center gap-2 mb-6">
        <?php if($isTransmigration): ?>
            <input type="hidden" name="type" value="transmigrasi">
        <?php endif; ?>

        <div class="flex-1 flex items-center px-3">
            <?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'search','class' => 'w-4 h-4 text-gray-400 mr-2.5 flex-shrink-0']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'search','class' => 'w-4 h-4 text-gray-400 mr-2.5 flex-shrink-0']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
            <input type="text" name="q" value="<?php echo e(request('q')); ?>" placeholder="Cari program..."
                   class="w-full py-2 text-sm text-gray-800 placeholder-gray-400 focus:outline-none">
        </div>

        <div class="hidden md:block w-px h-6 bg-gray-200"></div>

        <div class="px-2">
            <select name="category" class="w-full md:w-44 py-2 text-sm text-gray-700 bg-transparent focus:outline-none">
                <option value="">Kategori / jenis</option>
                <option value="pelatihan" <?php echo e(request('category') == 'pelatihan' ? 'selected' : ''); ?>>Pelatihan Vokasi</option>
                <option value="transmigrasi" <?php echo e(request('category') == 'transmigrasi' ? 'selected' : ''); ?>>Transmigrasi</option>
            </select>
        </div>

        <button type="submit" class="px-7 py-2.5 bg-[#112F28] hover:bg-[#1B4A40] text-white text-sm font-semibold rounded-full transition">
            Cari
        </button>
    </form>

    <!-- Programs Grid -->
    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
        <?php $__empty_1 = true; $__currentLoopData = $programs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $program): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <a href="<?php echo e(route('site.programs.show', $program->slug)); ?>"
               class="bg-white rounded-3xl p-6 sm:p-7 border border-gray-100 shadow-xs hover:shadow-md transition flex flex-col justify-between group">
                <div>
                    <div class="mb-4">
                        <?php if (isset($component)) { $__componentOriginal2ddbc40e602c342e508ac696e52f8719 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2ddbc40e602c342e508ac696e52f8719 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.badge','data' => ['variant' => 'success']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['variant' => 'success']); ?>Pendaftaran dibuka <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2ddbc40e602c342e508ac696e52f8719)): ?>
<?php $attributes = $__attributesOriginal2ddbc40e602c342e508ac696e52f8719; ?>
<?php unset($__attributesOriginal2ddbc40e602c342e508ac696e52f8719); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2ddbc40e602c342e508ac696e52f8719)): ?>
<?php $component = $__componentOriginal2ddbc40e602c342e508ac696e52f8719; ?>
<?php unset($__componentOriginal2ddbc40e602c342e508ac696e52f8719); ?>
<?php endif; ?>
                    </div>

                    <h2 class="text-xl font-bold text-gray-900 group-hover:text-[#112F28] transition mb-1">
                        <?php echo e($program->title); ?>

                    </h2>
                    <p class="text-sm text-gray-600 mb-4">
                        UPTD Pelatihan Kerja Kupang
                    </p>

                    <div class="flex flex-wrap items-center gap-2 text-xs mb-5">
                        <span class="px-2.5 py-1 rounded-md font-semibold bg-[#DBEAFE] text-[#1D4ED8]"><?php echo e($program->quota ?? '30'); ?> peserta</span>
                        <span class="px-2.5 py-1 rounded-md font-semibold bg-[#DCFCE7] text-[#15803D]"><?php echo e($program->fee == 0 ? 'Gratis' : 'Rp '.number_format($program->fee, 0, ',', '.')); ?></span>
                        <span class="px-2.5 py-1 rounded-md font-semibold bg-[#F3F4F6] text-[#374151]">Kupang</span>
                    </div>
                </div>

                <div class="pt-4 border-t border-gray-100 flex items-center justify-between text-xs">
                    <span class="text-amber-700 font-medium">
                        <?php if($program->start_date): ?>
                            Pendaftaran ditutup: <?php echo e($program->start_date->format('d M Y')); ?>

                        <?php else: ?>
                            Jadwal menyusul
                        <?php endif; ?>
                    </span>
                    <span class="text-base font-bold text-[#112F28] group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform">&nearr;</span>
                </div>
            </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="col-span-full bg-white rounded-3xl p-12 text-center border border-gray-100">
                <p class="text-gray-500 text-sm">Belum ada program yang tersedia saat ini.</p>
            </div>
        <?php endif; ?>
    </div>

    <?php if (isset($component)) { $__componentOriginal41032d87daf360242eb88dbda6c75ed1 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal41032d87daf360242eb88dbda6c75ed1 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.pagination','data' => ['paginator' => $programs]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('pagination'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['paginator' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($programs)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal41032d87daf360242eb88dbda6c75ed1)): ?>
<?php $attributes = $__attributesOriginal41032d87daf360242eb88dbda6c75ed1; ?>
<?php unset($__attributesOriginal41032d87daf360242eb88dbda6c75ed1); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal41032d87daf360242eb88dbda6c75ed1)): ?>
<?php $component = $__componentOriginal41032d87daf360242eb88dbda6c75ed1; ?>
<?php unset($__componentOriginal41032d87daf360242eb88dbda6c75ed1); ?>
<?php endif; ?>

    <p class="text-xs text-gray-400 mt-8">
        Informasi lengkap dan pendaftaran tersedia pada halaman masing-masing program.
    </p>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.site', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\disnaker-ntt\resources\views/site/programs/index.blade.php ENDPATH**/ ?>