
<?php $__env->startSection('title', 'Lacak Layanan PPID'); ?>

<?php $__env->startSection('content'); ?>
    <div class="max-w-xl mx-auto px-4 py-16">
        <div class="bg-white rounded-xl shadow-lg p-8 text-center border-t-4 border-slate-800">
            <div class="text-5xl mb-4">🎫</div>
            <h1 class="text-2xl font-bold text-slate-800 mb-2">Lacak Layanan PPID</h1>
            <p class="text-gray-600 mb-6 text-sm">Masukkan Nomor Tiket Permohonan/Keberatan Anda.</p>

            <?php if(session('success_ticket')): ?>
                <div class="bg-green-50 border border-green-200 text-green-800 p-4 rounded-lg mb-6 text-left">
                    <p class="font-bold mb-1">✅ Formulir Berhasil Dikirim!</p>
                    <p class="text-2xl font-mono font-bold mt-1 tracking-wider bg-white p-2 rounded border text-center select-all"><?php echo e(session('success_ticket')); ?></p>
                </div>
            <?php endif; ?>

            <form method="POST" action="<?php echo e(route('site.ppid.trackResult')); ?>" class="flex flex-col gap-3">
                <?php echo csrf_field(); ?>
                <input type="text" name="ticket_number" value="<?php echo e(session('success_ticket') ?? old('ticket_number')); ?>" required placeholder="Contoh: REQ-PPID-20231108-A1B2" class="w-full border-2 border-gray-300 rounded-lg px-4 py-3 text-center text-lg font-mono focus:border-slate-800 focus:ring-0 uppercase">
                <button type="submit" class="bg-slate-800 text-white font-bold py-3 rounded-lg hover:bg-slate-900 transition shadow">Lacak Status</button>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.site', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\disnaker-ntt\resources\views/site/ppid/track.blade.php ENDPATH**/ ?>