<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['variant' => 'success']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['variant' => 'success']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php
    $variants = [
        'success' => 'bg-[#D1E7DD] text-[#112F28]',
        'warning' => 'bg-amber-100 text-amber-800',
        'danger' => 'bg-red-100 text-red-800',
        'neutral' => 'bg-gray-100 text-gray-700',
    ];
?>

<span <?php echo e($attributes->merge(['class' => "inline-flex items-center px-2.5 py-1 rounded-md text-xs font-bold uppercase tracking-wide " . ($variants[$variant] ?? $variants['success'])] )); ?>>
    <?php echo e($slot); ?>

</span><?php /**PATH C:\xampp\htdocs\disnaker-ntt\resources\views/components/badge.blade.php ENDPATH**/ ?>