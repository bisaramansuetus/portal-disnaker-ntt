<?php $__env->startSection('title', $page?->meta_title ?: $pageTitle); ?>
<?php $__env->startSection('meta_description', $page?->meta_description ?: Str::limit(strip_tags($page?->content ?? ''), 150)); ?>

<?php $__env->startSection('content'); ?>
    <?php
        // Mengambil logo dari pengaturan admin
        $logo = \App\Models\SiteSetting::get('logo_path');
    ?>

    <div class="max-w-5xl mx-auto px-4 py-12">
        <div class="bg-white rounded-xl shadow-sm border-t-4 border-ntt-gold p-8 md:p-12 relative overflow-hidden">
            
            
            <?php if($logo): ?>
                <div class="absolute inset-0 z-0 opacity-[0.04] pointer-events-none bg-center bg-no-repeat" 
                     style="background-image: url('<?php echo e(asset('storage/' . $logo)); ?>'); background-size: 70%;">
                </div>
            <?php endif; ?>

            
            <div class="relative z-10">
                
                
                <div class="flex items-center gap-5 md:gap-6 mb-10 pb-6 border-b border-gray-200">
                    
                    
                    <div class="w-20 h-20 md:w-24 md:h-24 bg-white border-2 border-gray-100 rounded-xl flex items-center justify-center p-2 shadow-sm shrink-0">
                        <?php if($logo): ?>
                            <img src="<?php echo e(asset('storage/' . $logo)); ?>" alt="Logo Dinas" class="w-full h-full object-contain">
                        <?php else: ?>
                            <span class="text-[10px] text-gray-400 text-center leading-tight">Belum ada<br>logo</span>
                        <?php endif; ?>
                    </div>
                    
                    
                    <h1 class="text-3xl md:text-4xl font-bold text-ntt-red font-serif leading-tight">
                        <?php echo e($page->title ?? $pageTitle); ?>

                    </h1>
                </div>

                
                <?php if($page): ?>
                    <div class="prose prose-lg max-w-none text-gray-700 leading-relaxed 
                                prose-headings:text-ntt-red prose-headings:font-serif 
                                prose-hr:border-ntt-gold">
                        <?php echo $page->content; ?>

                    </div>

                    
                    <?php if($page->image): ?>
                        <div class="mt-10 pt-8 border-t-2 border-dashed border-gray-200">
                            <img src="<?php echo e(asset('storage/' . $page->image)); ?>" alt="Struktur Organisasi" class="w-full rounded-lg shadow-md">
                        </div>
                    <?php endif; ?>

                    <p class="text-xs text-gray-400 mt-12 pt-4 border-t border-gray-100">
                        Terakhir diperbarui: <?php echo e($page->updated_at->translatedFormat('d F Y')); ?>

                    </p>
                <?php else: ?>
                    <div class="bg-yellow-50 border border-yellow-300 text-yellow-800 rounded p-4">
                        Konten halaman belum tersedia.
                    </div>
                <?php endif; ?>

                
                    
                    <?php if(isset($structures) && $structures->count() > 0): ?>
                        <div class="mt-12 pt-8 border-t border-gray-100 text-center">
                            <h3 class="text-xl font-bold text-gray-900 mb-4">Struktur Organisasi</h3>
                            <button type="button" onclick="openStructureModal()" class="inline-flex items-center px-6 py-3 bg-[#112F28] hover:bg-[#1B4A40] text-white text-sm font-semibold rounded-full transition shadow-lg">
                                Lihat Struktur Dinas Terbaru
                            </button>
                        </div>

                        
                        <div id="structureModal" class="fixed inset-0 z-50 hidden overflow-y-auto">
                            <div class="flex items-center justify-center min-h-screen px-4 py-10">
                                <div class="fixed inset-0 bg-black/60 backdrop-blur-sm" onclick="closeStructureModal()"></div>

                                <div class="relative bg-white rounded-3xl w-full max-w-4xl shadow-2xl z-10 overflow-hidden flex flex-col max-h-[90vh]">
                                    <!-- Header Modal -->
                                    <div class="px-6 py-4 border-b border-gray-100 flex items-center justify-between bg-gray-50">
                                        <h3 class="text-xl font-extrabold text-[#112F28]">Struktur Kedinasan</h3>
                                        <button type="button" onclick="closeStructureModal()" class="text-gray-500 hover:text-red-600 text-2xl font-bold">&times;</button>
                                    </div>

                                    <!-- Body Modal -->
                                    <div class="p-6 overflow-y-auto">
                                        <!-- Pilihan Tahun -->
                                        <div class="flex gap-2 mb-6 border-b pb-4 overflow-x-auto">
                                            <?php $__currentLoopData = $structures; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $struct): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <button type="button" onclick="switchStructure(<?php echo e($index); ?>)" 
                                                        class="year-tab px-4 py-2 text-sm font-bold rounded-full transition whitespace-nowrap <?php echo e($index === 0 ? 'bg-[#112F28] text-white' : 'bg-gray-100 text-gray-600 hover:bg-gray-200'); ?>">
                                                    <?php echo e($struct->year); ?>

                                                </button>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>

                                        <!-- Konten per Tahun -->
                                        <?php $__currentLoopData = $structures; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $struct): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div id="structure-content-<?php echo e($index); ?>" class="structure-content <?php echo e($index !== 0 ? 'hidden' : ''); ?>">
                                                <div class="text-center mb-6">
                                                    <h4 class="text-2xl font-bold text-gray-900"><?php echo e($struct->title); ?> <?php echo e($struct->year); ?></h4>
                                                    <?php if($struct->description): ?>
                                                        <p class="text-sm text-gray-500 mt-1"><?php echo e($struct->description); ?></p>
                                                    <?php endif; ?>
                                                </div>

                                                <!-- Foto Kepala & Sekretaris (Jika ada) -->
                                                <div class="flex justify-center gap-10 mb-8">
                                                    <?php if($struct->head_photo || $struct->head_name): ?>
                                                        <div class="text-center">
                                                            <?php if($struct->head_photo): ?>
                                                                <img src="<?php echo e(asset('storage/'.$struct->head_photo)); ?>" class="w-24 h-24 object-cover rounded-full mx-auto border-4 border-[#E3EAE5] shadow-sm">
                                                            <?php else: ?>
                                                                <div class="w-24 h-24 bg-gray-200 rounded-full mx-auto"></div>
                                                            <?php endif; ?>
                                                            <p class="mt-2 font-bold text-gray-900"><?php echo e($struct->head_name); ?></p>
                                                            <p class="text-xs text-gray-500">Kepala Dinas</p>
                                                        </div>
                                                    <?php endif; ?>

                                                    <?php if($struct->secretary_photo || $struct->secretary_name): ?>
                                                        <div class="text-center">
                                                            <?php if($struct->secretary_photo): ?>
                                                                <img src="<?php echo e(asset('storage/'.$struct->secretary_photo)); ?>" class="w-24 h-24 object-cover rounded-full mx-auto border-4 border-[#E3EAE5] shadow-sm">
                                                            <?php else: ?>
                                                                <div class="w-24 h-24 bg-gray-200 rounded-full mx-auto"></div>
                                                            <?php endif; ?>
                                                            <p class="mt-2 font-bold text-gray-900"><?php echo e($struct->secretary_name); ?></p>
                                                            <p class="text-xs text-gray-500">Sekretaris</p>
                                                        </div>
                                                    <?php endif; ?>
                                                </div>

                                                <!-- Bagan Utama -->
                                                <?php if($struct->chart_image): ?>
                                                    <div class="rounded-xl overflow-hidden border border-gray-200 bg-gray-50 p-2">
                                                        <img src="<?php echo e(asset('storage/'.$struct->chart_image)); ?>" class="w-full h-auto rounded-lg" alt="Bagan Struktur">
                                                    </div>
                                                <?php else: ?>
                                                    <p class="text-center text-gray-400 py-10">Gambar bagan belum diunggah oleh admin.</p>
                                                <?php endif; ?>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>

                    <?php $__env->startPush('scripts'); ?>
                    <script>
                        function openStructureModal() {
                            document.getElementById('structureModal').classList.remove('hidden');
                            document.body.style.overflow = 'hidden';
                        }

                        function closeStructureModal() {
                            document.getElementById('structureModal').classList.add('hidden');
                            document.body.style.overflow = '';
                        }

                        function switchStructure(index) {
                            // Sembunyikan semua konten
                            document.querySelectorAll('.structure-content').forEach(el => el.classList.add('hidden'));
                            // Tampilkan yang dipilih
                            document.getElementById('structure-content-' + index).classList.remove('hidden');

                            // Ubah warna tab
                            document.querySelectorAll('.year-tab').forEach(el => {
                                el.classList.remove('bg-[#112F28]', 'text-white');
                                el.classList.add('bg-gray-100', 'text-gray-600');
                            });
                            const activeTab = document.querySelectorAll('.year-tab')[index];
                            activeTab.classList.remove('bg-gray-100', 'text-gray-600');
                            activeTab.classList.add('bg-[#112F28]', 'text-white');
                        }
                    </script>
                    <?php $__env->stopPush(); ?>
                
            </div>

            
            
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.site', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\disnaker-ntt\resources\views/site/pages/show.blade.php ENDPATH**/ ?>