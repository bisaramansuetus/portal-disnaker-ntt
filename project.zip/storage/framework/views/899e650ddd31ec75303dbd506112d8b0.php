<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['variant' => 'primary', 'type' => 'submit', 'url' => null]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['variant' => 'primary', 'type' => 'submit', 'url' => null]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php
    $baseClasses = "inline-flex items-center justify-center font-semibold px-6 py-2.5 rounded-full transition duration-150 ease-in-out text-sm focus:outline-none";
    
    $variants = [
        'primary' => "bg-[#112F28] hover:bg-[#1B4A40] text-white",
        'secondary' => "bg-[#D1E7DD] hover:bg-[#A3CFBB] text-[#112F28]",
        'white' => "bg-white hover:bg-gray-100 text-[#112F28]",
        'danger' => "bg-[#DC3545] hover:bg-red-700 text-white",
        'outline' => "border border-[#112F28] bg-transparent hover:bg-[#112F28] text-[#112F28] hover:text-white"
    ];
    $classes = $baseClasses . ' ' . ($variants[$variant] ?? $variants['primary']);
?>

<?php if($url): ?>
    <a href="<?php echo e($url); ?>" <?php echo e($attributes->merge(['class' => $classes])); ?>>
        <?php echo e($slot); ?>

    </a>
<?php else: ?>
    <button type="<?php echo e($type); ?>" <?php echo e($attributes->merge(['class' => $classes])); ?>>
        <?php echo e($slot); ?>

    </button>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\disnaker-ntt\resources\views/components/button.blade.php ENDPATH**/ ?>