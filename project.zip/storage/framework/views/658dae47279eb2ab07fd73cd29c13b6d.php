<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['paginator']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['paginator']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php if($paginator instanceof \Illuminate\Pagination\LengthAwarePaginator && $paginator->hasPages()): ?>
    <div class="flex flex-col sm:flex-row items-center justify-between gap-4 pt-8 mt-8 border-t border-gray-200/70">
        <p class="text-xs text-gray-500">
            Menampilkan <span class="font-semibold text-gray-800"><?php echo e($paginator->firstItem()); ?>–<?php echo e($paginator->lastItem()); ?></span> dari <span class="font-semibold text-gray-800"><?php echo e($paginator->total()); ?></span> data
        </p>

        <nav class="inline-flex items-center bg-white border border-gray-200 rounded-full p-1 shadow-xs" aria-label="Pagination">
            <?php if($paginator->onFirstPage()): ?>
                <span class="px-3 py-1.5 text-xs text-gray-300 cursor-not-allowed">&larr; Sebelumnya</span>
            <?php else: ?>
                <a href="<?php echo e($paginator->previousPageUrl()); ?>" class="px-3 py-1.5 text-xs font-medium text-gray-700 hover:bg-gray-100 rounded-full transition">&larr; Sebelumnya</a>
            <?php endif; ?>

            <div class="flex items-center space-x-1 px-1">
                <?php $__currentLoopData = $paginator->getUrlRange(max(1, $paginator->currentPage() - 2), min($paginator->lastPage(), $paginator->currentPage() + 2)); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($page == $paginator->currentPage()): ?>
                        <span class="w-7 h-7 flex items-center justify-center rounded-full bg-[#112F28] text-white text-xs font-bold"><?php echo e($page); ?></span>
                    <?php else: ?>
                        <a href="<?php echo e($url); ?>" class="w-7 h-7 flex items-center justify-center rounded-full text-xs font-medium text-gray-600 hover:bg-gray-100 transition"><?php echo e($page); ?></a>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <?php if($paginator->hasMorePages()): ?>
                <a href="<?php echo e($paginator->nextPageUrl()); ?>" class="px-3 py-1.5 text-xs font-medium text-[#112F28] hover:bg-[#E3EAE5] rounded-full transition">Berikutnya &rarr;</a>
            <?php else: ?>
                <span class="px-3 py-1.5 text-xs text-gray-300 cursor-not-allowed">Berikutnya &rarr;</span>
            <?php endif; ?>
        </nav>
    </div>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\disnaker-ntt\resources\views/components/pagination.blade.php ENDPATH**/ ?>