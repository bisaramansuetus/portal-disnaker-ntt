<?php $__env->startSection('title', 'Kontak & Bantuan'); ?>

<?php $__env->startSection('content'); ?>
    <div class="max-w-5xl mx-auto px-4 py-10">
        <h1 class="text-3xl font-bold mb-2">Kontak & Bantuan</h1>
        <p class="text-gray-600 mb-8">Hubungi kami atau temukan jawaban atas pertanyaan umum.</p>

        
        <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-10">
            <div class="bg-white rounded-lg shadow p-6">
                <h2 class="font-bold text-lg mb-4">Kantor</h2>
                <dl class="space-y-3 text-sm">
                    <div>
                        <dt class="text-gray-500">Alamat</dt>
                        <dd class="font-medium"><?php echo e(\App\Models\SiteSetting::get('office_address', 'Belum diisi')); ?></dd>
                    </div>
                    <div>
                        <dt class="text-gray-500">Telepon</dt>
                        <dd class="font-medium"><?php echo e(\App\Models\SiteSetting::get('office_phone', 'Belum diisi')); ?></dd>
                    </div>
                    <div>
                        <dt class="text-gray-500">Email</dt>
                        <dd class="font-medium">
                            <?php $email = \App\Models\SiteSetting::get('office_email'); ?>
                            <?php if($email): ?>
                                <a href="mailto:<?php echo e($email); ?>" class="text-blue-600 hover:underline"><?php echo e($email); ?></a>
                            <?php else: ?> Belum diisi <?php endif; ?>
                        </dd>
                    </div>
                </dl>

                <div class="mt-4 flex gap-2">
                    <?php if($fb = \App\Models\SiteSetting::get('facebook_url')): ?>
                        <a href="<?php echo e($fb); ?>" target="_blank" rel="noopener" class="text-xs px-3 py-1 bg-blue-600 text-white rounded">Facebook</a>
                    <?php endif; ?>
                    <?php if($ig = \App\Models\SiteSetting::get('instagram_url')): ?>
                        <a href="<?php echo e($ig); ?>" target="_blank" rel="noopener" class="text-xs px-3 py-1 bg-pink-600 text-white rounded">Instagram</a>
                    <?php endif; ?>
                    <?php if($yt = \App\Models\SiteSetting::get('youtube_url')): ?>
                        <a href="<?php echo e($yt); ?>" target="_blank" rel="noopener" class="text-xs px-3 py-1 bg-red-600 text-white rounded">YouTube</a>
                    <?php endif; ?>
                </div>
            </div>

            <div class="bg-white rounded-lg shadow overflow-hidden">
                <?php $map = \App\Models\SiteSetting::get('office_map_embed'); ?>
                <?php if($map): ?>
                    <div class="aspect-video w-full"><?php echo $map; ?></div>
                <?php else: ?>
                    <div class="aspect-video bg-gray-100 flex items-center justify-center text-gray-400 text-sm">
                        Peta belum disetel
                    </div>
                <?php endif; ?>
            </div>
        </div>

        
        <div class="mb-10">
            <h2 class="text-2xl font-bold mb-4">Pertanyaan Umum (FAQ)</h2>
            <?php if($faq): ?>
                <div class="bg-white rounded-lg shadow p-6 prose max-w-none">
                    <?php echo $faq->content; ?>

                </div>
            <?php else: ?>
                <div class="bg-white rounded-lg shadow p-6 text-gray-500 text-sm">
                    FAQ belum tersedia. Admin dapat membuatnya di Panel Admin → Berita & Pengumuman → Konten tipe <strong>Halaman</strong> dengan slug <code>faq</code>.
                </div>
            <?php endif; ?>
        </div>

        
        <div>
            <h2 class="text-2xl font-bold mb-4">Layanan Terkait</h2>
            <div class="grid grid-cols-1 md:grid-cols-2 gap-3">
                <?php
                    $links = [
                        ['label' => 'Kementerian Ketenagakerjaan RI', 'url' => 'https://kemnaker.go.id'],
                        ['label' => 'Kartu Prakerja', 'url' => 'https://www.prakerja.go.id'],
                        ['label' => 'BPJS Ketenagakerjaan', 'url' => 'https://www.bpjsketenagakerjaan.go.id'],
                        ['label' => 'Portal Pemerintah Provinsi NTT', 'url' => 'https://nttprov.go.id'],
                    ];
                ?>
                <?php $__currentLoopData = $links; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e($link['url']); ?>" target="_blank" rel="noopener"
                       class="bg-white rounded-lg shadow hover:shadow-lg px-4 py-3 flex items-center justify-between transition">
                        <span class="font-medium text-sm"><?php echo e($link['label']); ?></span>
                        <span class="text-blue-600 text-sm">↗</span>
                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.site', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\disnaker-ntt\resources\views/site/contact.blade.php ENDPATH**/ ?>